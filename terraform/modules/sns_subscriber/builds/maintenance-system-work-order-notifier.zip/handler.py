import json
import logging
import os
import time

import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)

_sqs_client = None
_ses_client = None
_dynamodb_client = None


def _get_sqs_client():
    global _sqs_client
    if _sqs_client is None:
        _sqs_client = boto3.client("sqs")
    return _sqs_client


def _get_ses_client():
    global _ses_client
    if _ses_client is None:
        _ses_client = boto3.client("ses")
    return _ses_client


def _get_dynamodb_client():
    global _dynamodb_client
    if _dynamodb_client is None:
        _dynamodb_client = boto3.client("dynamodb")
    return _dynamodb_client


def _mark_processed(idempotency_key: str) -> bool:
    """Atomically claims the key. Returns True if first time, False if duplicate."""
    ttl = int(time.time()) + 30 * 24 * 60 * 60  # 30 days
    try:
        _get_dynamodb_client().put_item(
            TableName=os.environ["IDEMPOTENCY_TABLE_NAME"],
            Item={
                "idempotency_key": {"S": idempotency_key},
                "expires_at": {"N": str(ttl)},
            },
            ConditionExpression="attribute_not_exists(idempotency_key)",
        )
        return True
    except ClientError as exc:
        if exc.response["Error"]["Code"] == "ConditionalCheckFailedException":
            return False
        raise


def _send_result(event_id: str, *, status: str, error: str = None):
    queue_url = os.environ["SQS_RESULTS_URL"]
    message = {"event_id": event_id, "status": status}
    if error:
        message["error"] = error
    _get_sqs_client().send_message(
        QueueUrl=queue_url,
        MessageBody=json.dumps(message),
    )


def _fmt(value) -> str:
    return value if value is not None else "—"


def _build_email_body(data: dict, action: str) -> str:
    assigned_to = data.get("assigned_to") or {}
    asset = data.get("asset") or {}
    work_order_type = data.get("work_order_type") or {}
    created_by = data.get("created_by") or {}

    priority = _fmt(data.get("priority")).capitalize()
    estimated_hours = data.get("estimated_hours")
    estimated_hours_str = f"{estimated_hours} h" if estimated_hours else "—"

    return (
        f"Hello {assigned_to.get('name', '')},\n\n"
        f'A work order assigned to you has been updated.\n\n'
        f"{'─' * 40}\n"
        f"EVENT\n"
        f"{'─' * 40}\n"
        f"  Action : {action}\n\n"
        f"{'─' * 40}\n"
        f"WORK ORDER\n"
        f"{'─' * 40}\n"
        f"  ID          : {_fmt(data.get('id'))}\n"
        f"  Title       : {_fmt(data.get('title'))}\n"
        f"  Type        : {_fmt(work_order_type.get('name'))}\n"
        f"  Status      : {_fmt(data.get('status'))}\n"
        f"  Priority    : {priority}\n"
        f"  Description : {_fmt(data.get('description'))}\n"
        f"  Notes       : {_fmt(data.get('notes'))}\n\n"
        f"{'─' * 40}\n"
        f"ASSET\n"
        f"{'─' * 40}\n"
        f"  Name          : {_fmt(asset.get('name'))}\n"
        f"  Serial number : {_fmt(asset.get('serial_number'))}\n"
        f"  Status        : {_fmt(asset.get('status'))}\n\n"
        f"{'─' * 40}\n"
        f"SCHEDULE\n"
        f"{'─' * 40}\n"
        f"  Scheduled date   : {_fmt(data.get('scheduled_date'))}\n"
        f"  Due date         : {_fmt(data.get('due_date'))}\n"
        f"  Estimated hours  : {estimated_hours_str}\n\n"
        f"{'─' * 40}\n"
        f"PEOPLE\n"
        f"{'─' * 40}\n"
        f"  Assigned to : {assigned_to.get('name', '—')} <{assigned_to.get('email', '—')}>\n"
        f"  Created by  : {created_by.get('name', '—')} <{created_by.get('email', '—')}>\n\n"
        f"{'─' * 40}\n"
        f"TIMESTAMPS\n"
        f"{'─' * 40}\n"
        f"  Created   : {_fmt(data.get('created_at'))}\n"
        f"  Updated   : {_fmt(data.get('updated_at'))}\n\n"
        f"Please log in to the platform to review the details.\n"
    )


def _send_email(*, to: str, data: dict, event_type: str):
    from_email = os.environ["SES_FROM_EMAIL"]
    action = event_type.split(".")[-1].replace("_", " ").capitalize()

    _get_ses_client().send_email(
        Source=from_email,
        Destination={"ToAddresses": [to]},
        Message={
            "Subject": {
                "Data": f"Work order: {data.get('title')} — {action}",
            },
            "Body": {
                "Text": {
                    "Data": _build_email_body(data, action),
                },
            },
        },
    )


def handle(event, context):
    for record in event["Records"]:
        event_id = None
        try:
            body = json.loads(record["body"])
            message = body.get("Message")
            if message:
                body = json.loads(message)

            event_id = body.get("id")
            idempotency_key = body.get("idempotency_key") or event_id
            event_type = body.get("event_type", "")
            data = body.get("payload", {}).get("data", {})

            logger.info(
                "Processing event id=%s type=%s tenant=%s asset_id=%s",
                event_id,
                event_type,
                body.get("tenant_id"),
                data.get("id"),
            )

            if not _mark_processed(idempotency_key):
                logger.info(
                    "Duplicate event skipped idempotency_key=%s event_id=%s",
                    idempotency_key,
                    event_id,
                )
                if event_id:
                    _send_result(event_id, status="processed")
                continue

            assigned_to_email = (data.get("assigned_to") or {}).get("email")

            if not assigned_to_email:
                logger.warning(
                    "No assigned_to email in event_id=%s, skipping email.",
                    event_id,
                )
            else:
                _send_email(to=assigned_to_email, data=data, event_type=event_type)
                logger.info(
                    "Email sent to=%s event_id=%s", assigned_to_email, event_id
                )

            if event_id:
                _send_result(event_id, status="processed")
                logger.info("Result sent: event_id=%s status=processed", event_id)

        except Exception as exc:
            logger.error(
                "Failed to process record event_id=%s: %s",
                event_id,
                exc,
                exc_info=True,
            )
            if event_id:
                _send_result(event_id, status="failed", error=str(exc))
                logger.info("Result sent: event_id=%s status=failed", event_id)
